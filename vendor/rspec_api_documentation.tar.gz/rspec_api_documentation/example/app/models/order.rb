class Order < ActiveRecord::Base
end
