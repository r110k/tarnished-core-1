module RspecApiDocumentation
  class Index
    def examples
      @examples ||= []
    end
  end
end
