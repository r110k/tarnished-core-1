module RspecApiDocumentation
  module OpenApi
    class Headers < Node
      CHILD_CLASS = Header
    end
  end
end
